(function ($) {
    "use strict";

    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Date and time picker
    $('.date').datetimepicker({
        format: 'L'
    });
    $('.time').datetimepicker({
        format: 'LT'
    });










    $(document).ready(function() {
        // Verificar si la página se cargó para editar una reserva
        var editando = sessionStorage.getItem('editando');
        var reservaId = sessionStorage.getItem('reservaId');
    
        if (editando === 'true' && reservaId) {
            
            cargarDatosReserva(reservaId); // Cargar los datos de la reserva en el formulario
        } // No se necesita un else si el formulario ya está por defecto vacío para nuevas reservas
    
        

        function getMapaReservas() {
            var reservasArray = JSON.parse(sessionStorage.getItem('reservas'));
            var reservasMap = new Map();
            reservasArray.forEach((item) => {
                reservasMap.set(item[0], item[1]);
            });
            return reservasMap;

        } 
        
        function getReserva(mapa,id) {

            return mapa.get(parseInt(id));
        
        }

        function cargarDatosReserva(id) {

            var reservasMap = getMapaReservas();    
            var reserva = getReserva(reservasMap,id);
            
            //$('#mensaje').html(reserva.persona).show();
            
            $('#nombre').val(reserva.nombre);
            $('#email').val(reserva.email);
            $('#date input').val(reserva.fecha); // Asegúrate de que este selector apunta correctamente al input dentro de #date
            $('#time input').val(reserva.hora); // Asegúrate de que este selector apunta correctamente al input dentro de #time
            $('#personas').val(reserva.personas.toString());
    

        }

        if (editando === null){//nueva reserva

            // Captura del evento de envío del formulario
            $('form').submit(function (event) {

            

            event.preventDefault(); // Evita que el formulario se envíe

            // Colocamos un indicador en localStorage para indicar que el formulario ha sido enviado
            sessionStorage.setItem('formularioEnviado', 'true');
            sessionStorage.setItem('nombre', $('#nombre').val());
            sessionStorage.setItem('email', $('#email').val());
            sessionStorage.setItem('fecha', $('#date input').val());
            sessionStorage.setItem('hora', $('#time input').val());
            sessionStorage.setItem('personas', $('#personas option:selected').val());

            // Obtenemos el nombre de la persona seleccionada
            var numeroPersonas = $('#personas option:selected').text();

            // Mostramos el mensaje personalizado dentro del elemento #mensaje
            $('#mensaje').html('Reserva realizada para <strong>' + numeroPersonas + '</strong>.').show();


            // Opcional: puedes resetear el formulario después de mostrar el mensaje
            this.reset();

            });
        }
        
        
        


        else{//editando reserva

            // Limpiar las variables para no afectar futuras cargas de la página
            sessionStorage.removeItem('editando');
            sessionStorage.removeItem('reservaId');
            
            $('form').submit(function (event) {

                event.preventDefault(); // Evita que el formulario se envíe
                var reservasMap = getMapaReservas();    
                
                var reserva = getReserva(reservasMap,reservaId);//sobra creo

                // Recoger los valores actuales del formulario
                var nombre = $('#nombre').val();
                var email = $('#email').val();
                var fecha = $('#date input').val();
                var hora = $('#time input').val();
                var personas = $('#personas').val();

                reservasMap.set(parseInt(reservaId), {
                    nombre: nombre,
                    email: email,
                    fecha: fecha,
                    hora: hora,
                    personas: personas
                });

                var nuevoReservasArray = Array.from(reservasMap.entries());
                sessionStorage.setItem('reservas', JSON.stringify(nuevoReservasArray));

                var nuevoReservasArray = Array.from(reservasMap.entries());
                sessionStorage.setItem('reservas', JSON.stringify(nuevoReservasArray));


                // Obtenemos el nombre de la persona seleccionada
                var numeroPersonas = $('#personas option:selected').text();

                // Mostramos el mensaje personalizado dentro del elemento #mensaje
                $('#mensaje').html('Reserva MODIFICADApara <strong>' + numeroPersonas + '</strong>.').show();


                // Opcional: puedes resetear el formulario después de mostrar el mensaje
                this.reset();








            });    
            
            





        }

    });

    




    


    
    
    

    

    

})(jQuery);
