package com.example.demo.aplication.controller;

import com.example.demo.aplication.model.Reserva;
import com.example.demo.aplication.service.ReservaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Controller class for handling reservation-related HTTP requests
@RestController
@RequestMapping("/api/reservas") // Sets the base URL path for this controller
public class ReservaController {

    @Autowired
    private ReservaService reservaService; // Automatically injects the ReservaService instance

    // Returns a list of all reservations
    @GetMapping
    public List<Reserva> listarReservas() {
        return reservaService.listarReservas();
    }

    // Creates a new reservation with the provided reservation details
    @PostMapping
    public Reserva crearReserva(@RequestBody Reserva reserva) {
        return reservaService.crearReserva(reserva);
    }

    // Updates an existing reservation identified by id with the provided reservation details
    @PutMapping("/{id}")
    public Reserva actualizarReserva(@PathVariable Long id, @RequestBody Reserva reservaActualizada) {
        return reservaService.actualizarReserva(id, reservaActualizada);
    }

    // Deletes a reservation identified by id
    @DeleteMapping("/{id}")
    public void eliminarReserva(@PathVariable Long id) {
        reservaService.eliminarReserva(id);
    }

    // Retrieves a reservation by its id
    @GetMapping("/{id}")
    public Reserva obtenerReservaPorId(@PathVariable Long id) {
        return reservaService.obtenerReservaPorId(id);
    }

    // Partially updates a reservation identified by id with the provided reservation details
    @PatchMapping("/{id}")
    public ResponseEntity<Reserva> actualizarParcialReserva(@PathVariable Long id, @RequestBody Reserva reserva) {
        Reserva reservaActualizada = reservaService.actualizarParcialReserva(id, reserva);
        if (reservaActualizada != null) {
            return new ResponseEntity<>(reservaActualizada, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
