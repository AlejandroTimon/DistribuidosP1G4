(function ($) {
    "use strict";

    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });




    var formularioUsuarioEnviado = sessionStorage.getItem('formularioUsuarioEnviado');
    var nombreCompleto = sessionStorage.getItem('nombreCompleto');
    var nombreUsuario = sessionStorage.getItem('nombreUsuario');
    var correoElectronico = sessionStorage.getItem('correoElectronico');
    var fechaNacimiento = sessionStorage.getItem('fechaNacimiento');

    // Mapa para almacenar los usuarios
    var usuariosMap = cargarUsuarios();

    /*
    var contadorId = cargarContadorId();

    function cargarContadorId() {
        var idGuardado = sessionStorage.getItem('contadorIdUsuarios');
        return idGuardado ? parseInt(idGuardado, 10) : 0; // Cargar el contador, o iniciar en 0 si no existe
    }

    function guardarContadorId() {
        sessionStorage.setItem('contadorIdUsuarios', contadorId.toString()); // Guardar el contador como cadena
    }

    function generarIdUnico() {
        var id = contadorId++; // Incrementa el contador y lo usa como ID
        guardarContadorId(); // Guardar el nuevo valor del contador en sessionStorage
        return id;
    }
    */

    function cargarUsuarios() {
        var usuariosArray = JSON.parse(sessionStorage.getItem('usuarios'));
        if (usuariosArray) {
            return new Map(usuariosArray);
        } else {
            return new Map();
        }
    }

    function guardarUsuarios() {
        var usuariosArray = Array.from(usuariosMap.entries());
        sessionStorage.setItem('usuarios', JSON.stringify(usuariosArray));
    }

    function agregarUsuario(nombreCompleto, nombreUsuario, correoElectronico, fechaNacimiento) {
        var id = nombreUsuario;
        var nuevoUsuario = {
            nombreCompleto: nombreCompleto,
            nombreUsuario: nombreUsuario,
            correoElectronico: correoElectronico,
            fechaNacimiento: fechaNacimiento
        };
        usuariosMap.set(id, nuevoUsuario);
        guardarUsuarios();
        mostrarUsuarios();
    }

    function mostrarUsuarios() {
        $('#socios').empty();
        usuariosMap.forEach((usuario, id) => {
            var usuarioHTML = `<div class="usuario" id="usuario-${id}">
                                    <h4>Nombre de Usuario: ${usuario.nombreUsuario}</h4>
                                    <p>Nombre Completo: ${usuario.nombreCompleto}</p>
                                    <p>Correo Electrónico: ${usuario.correoElectronico}</p>
                                    <p>Fecha de Nacimiento: ${usuario.fechaNacimiento}</p>
                                    <button class="editar-usuario btn-primary btn-block font-weight-bold" data-id="${id}">Editar</button>
                                    <button class="eliminar-usuario btn-primary btn-block font-weight-bold" data-id="${id}">Eliminar</button>
                                </div>`;
            $('#socios').append(usuarioHTML);
        });
    }

    

    function eliminarUsuario(id) {
        usuariosMap.delete(id);
        guardarUsuarios();
        mostrarUsuarios();
    }

    


    if (formularioUsuarioEnviado === 'true') {
        agregarUsuario(nombreCompleto, nombreUsuario, correoElectronico, fechaNacimiento);
        // Limpiar sessionStorage
        sessionStorage.removeItem('formularioUsuarioEnviado');
        sessionStorage.removeItem('nombreCompleto');
        sessionStorage.removeItem('nombreUsuario');
        sessionStorage.removeItem('correoElectronico');
        sessionStorage.removeItem('fechaNacimiento');
        formularioUsuarioEnviado = 'false';//no se si sobra,porque se elimina arriba
    } else {
        mostrarUsuarios();
    }

    
    

   


    $(document).ready(function() {
        $('#socios').on('click', '.eliminar-usuario', function() {
            var idUsuario = $(this).data('id');
            eliminarUsuario(idUsuario);
        });

        $('#socios').on('click', '.editar-usuario', function() {
            var usuarioId = $(this).data('id');
            sessionStorage.setItem('editandoUsuario', 'true');
            sessionStorage.setItem('usuarioId', usuarioId);
            window.location.href = 'registrarse.html'; // Asegúrate de que este es el nombre correcto de tu página de registro/edición
        });
    });

})(jQuery);
