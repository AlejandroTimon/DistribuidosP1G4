package com.example.demo.aplication.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import com.example.demo.aplication.model.Evento;

// Service class for event-related business logic
public class EventoService {
    private List<Evento> eventos = new ArrayList<>(); // List to store events
    private AtomicLong contador = new AtomicLong(); // Counter for generating unique event IDs

    // Returns a list of all events
    public List<Evento> listarEventos() {
        return eventos;
    }

    // Retrieves an event by its ID
    public Evento obtenerEventoPorId(Long id) {
        return eventos.stream()
                .filter(evento -> evento.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    // Creates a new event and adds it to the list
    public Evento crearEvento(Evento evento) {
        evento.setId(contador.incrementAndGet()); // Sets a unique ID
        eventos.add(evento);
        return evento;
    }

    // Updates an existing event identified by ID with new details
    public Evento actualizarEvento(Long id, Evento eventoActualizado) {
        Evento evento = obtenerEventoPorId(id);
        if (evento != null) {
            evento.setTitulo(eventoActualizado.getTitulo());
            evento.setDescripcion(eventoActualizado.getDescripcion());
            evento.setFechaEvento(eventoActualizado.getFechaEvento());
            evento.setOrganizador(eventoActualizado.getOrganizador());
            return evento;
        }
        return null;
    }

    // Removes an event from the list by its ID
    public void eliminarEvento(Long id) {
        eventos.removeIf(evento -> evento.getId().equals(id));
    }

    // Partially updates an event identified by ID with provided details
    public Evento actualizarParcialEvento(Long id, Evento eventoParcial) {
        Evento evento = obtenerEventoPorId(id);
        if (evento != null) {
            if (eventoParcial.getTitulo() != null) evento.setTitulo(eventoParcial.getTitulo());
            if (eventoParcial.getDescripcion() != null) evento.setDescripcion(eventoParcial.getDescripcion());
            if (eventoParcial.getFechaEvento() != null) evento.setFechaEvento(eventoParcial.getFechaEvento());
            if (eventoParcial.getOrganizador() != null) evento.setOrganizador(eventoParcial.getOrganizador());
            return evento;
        }
        return null;
    }
}
