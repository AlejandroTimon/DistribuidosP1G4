(function ($) {
    "use strict";

    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });




    var formularioEnviado = sessionStorage.getItem('formularioEnviado');
    var nombre = sessionStorage.getItem('nombre');
    var email = sessionStorage.getItem('email');
    var fecha = sessionStorage.getItem('fecha');
    var hora = sessionStorage.getItem('hora');
    var personas = sessionStorage.getItem('personas');

    // Array para almacenar las reservas
    var reservasMap = cargarReservas();

    var contadorId = cargarContadorId();

    function cargarContadorId() {
        var idGuardado = sessionStorage.getItem('contadorId');
        return idGuardado ? parseInt(idGuardado, 10) : 0; // Cargar el contador, o iniciar en 0 si no existe
    }

    function guardarContadorId() {
        sessionStorage.setItem('contadorId', contadorId.toString()); // Guardar el contador como cadena
    }

    function generarIdUnico() {
        var id = contadorId++; // Incrementa el contador y lo usa como ID
        guardarContadorId(); // Guardar el nuevo valor del contador en sessionStorage
        return id;
    }

    function cargarReservas() {
        var reservasArray = JSON.parse(sessionStorage.getItem('reservas'));
        if (reservasArray) {
            return new Map(reservasArray); // Reconstruye el Map desde el arreglo de arreglos
        } else {
            return new Map(); // Retorna un nuevo Map vacío si no hay datos guardados
        }
    }

    function guardarReservas() {
        var reservasArray = Array.from(reservasMap.entries()); // Convierte el Map a un arreglo de arreglos
        sessionStorage.setItem('reservas', JSON.stringify(reservasArray));
    }

    function agregarReserva(nombrePersona, email, fecha, hora, personas) {
        var id= generarIdUnico();
        var nuevaReserva = {
            nombre: nombrePersona,
            email: email,
            fecha: fecha,
            hora: hora,
            personas: personas
        };
        reservasMap.set(id, nuevaReserva);
        guardarReservas(); // Guarda el estado actual de reservas en sessionStorage
        mostrarReservas();
    }

    function mostrarReservas() {
        $('#reservas').empty();
        reservasMap.forEach((reserva, id) => { // Aquí 'id' es la clave en el Map, que es el ID único de la reserva
            
            var reservaHTML = `<div class="reserva" id="reserva-${id}"> 
                                    <h4>id: ${id} -nombre de usuario: ${reserva.nombre}</h4>
                                    <p>Email: ${reserva.email}</p>
                                    <p>Fecha: ${reserva.fecha}</p>
                                    <p>Hora: ${reserva.hora}</p>
                                    <p>Numero de comensales: ${reserva.personas}</p>
                                    <button class="editar-reserva" data-id="${id}">Editar</a>
                                    <button class="eliminar-reserva" data-id="${id}">Eliminar</button>
                                </div>`;
            $('#reservas').append(reservaHTML);
        });
    }

    

    function eliminarReserva(id) {
        reservasMap.delete(id);
        guardarReservas(); // Actualiza el estado guardado tras eliminar una reserva
        mostrarReservas();
    }

    


    if (formularioEnviado === 'true') {
        agregarReserva(nombre, email, fecha, hora, personas);
        // Limpiamos el indicador en localStorage
        sessionStorage.removeItem('formularioEnviado');
        sessionStorage.removeItem('nombre');
        sessionStorage.removeItem('email');
        sessionStorage.removeItem('fecha');
        sessionStorage.removeItem('hora');
        sessionStorage.removeItem('personas');
        formularioEnviado = 'false'; // Establece la variable a 'false'
    } else {
        // Mostrar las reservas existentes al cargar la página
        mostrarReservas();
    }

    
    

   


    $(document).ready(function() {
        // Otros códigos de inicialización
    
        // Delegación de eventos para capturar clic en botones de eliminar
        $('#reservas').on('click', '.eliminar-reserva', function() {
            var idReserva = parseInt($(this).data('id')); // Obtener el ID desde el atributo data-id
            eliminarReserva(idReserva);
        });
    
        // Delegación de eventos para capturar clic en botones de editar
        $('#reservas').on('click', '.editar-reserva', function() {
            var reservaId = $(this).data('id'); // Asume que este es el ID de la reserva a editar
            sessionStorage.setItem('editando', 'true');
            sessionStorage.setItem('reservaId', reservaId.toString());
            window.location.href = 'reserva.html'; // Redirige al usuario a la página de reserva
        });
    });

})(jQuery);
