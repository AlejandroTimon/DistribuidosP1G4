package com.example.demo.aplication.service;

import org.springframework.stereotype.Service;

import com.example.demo.aplication.model.Reserva;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

// Service class for reservation-related business logic
@Service
public class ReservaService {
    private static final List<Reserva> reservas = new ArrayList<>(); // List to store reservations
    private final AtomicLong contador = new AtomicLong(); // Counter for generating unique reservation IDs

    // Returns a list of all reservations
    public List<Reserva> listarReservas() {
        return reservas;
    }

    // Retrieves a reservation by its ID
    public Reserva obtenerReservaPorId(Long id) {
        return reservas.stream()
                .filter(reserva -> reserva.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    // Creates a new reservation and adds it to the list
    public Reserva crearReserva(Reserva reserva) {
        reserva.setId(contador.incrementAndGet()); // Sets a unique ID
        reservas.add(reserva);
        return reserva;
    }

    // Updates an existing reservation identified by ID with new details
    public Reserva actualizarReserva(Long id, Reserva reservaActualizada) {
        Reserva reserva = obtenerReservaPorId(id);
        if (reserva != null) {
            reserva.setNombreUsuario(reservaActualizada.getNombreUsuario());
            reserva.setEmail(reservaActualizada.getEmail());
            reserva.setFecha(reservaActualizada.getFecha());
            reserva.setNumeroPersonas(reservaActualizada.getNumeroPersonas());
            return reserva;
        }
        return null;
    }

    // Removes a reservation from the list by its ID
    public boolean eliminarReserva(Long id) {
        return reservas.removeIf(reserva -> reserva.getId().equals(id));
    }

    // Partially updates a reservation identified by ID with provided details
    public Reserva actualizarParcialReserva(Long id, Reserva reservaParcial) {
        Reserva reservaExistente = obtenerReservaPorId(id);
        if (reservaExistente != null) {
            if (reservaParcial.getNombreUsuario() != null) reservaExistente.setNombreUsuario(reservaParcial.getNombreUsuario());
            if (reservaParcial.getEmail() != null) reservaExistente.setEmail(reservaParcial.getEmail());
            if (reservaParcial.getFecha() != null) reservaExistente.setFecha(reservaParcial.getFecha());
            if (reservaParcial.getNumeroPersonas() != 0) reservaExistente.setNumeroPersonas(reservaParcial.getNumeroPersonas());
            return reservaExistente;
        }
        return null;
    }
}
