package com.example.demo.aplication.controller;
import org.springframework.web.bind.annotation.*;

import com.example.demo.aplication.model.Usuario;
import com.example.demo.aplication.service.UsuarioService;

import java.util.List;

// Controller class for managing user-related HTTP requests
@RestController
@RequestMapping("/api/usuarios") // Base URL for all methods in this class
public class UsuarioController {
    private final UsuarioService usuarioService = new UsuarioService(); // Service class to handle business logic

    // Method to list all users
    @GetMapping
    public List<Usuario> listarUsuarios() {
        return usuarioService.listarUsuarios();
    }

    // Method to fetch a user by their ID
    @GetMapping("/{id}")
    public Usuario obtenerUsuarioPorId(@PathVariable Long id) {
        return usuarioService.obtenerUsuarioPorId(id);
    }

    // Method to create a new user
    @PostMapping
    public Usuario crearUsuario(@RequestBody Usuario usuario) {
        return usuarioService.crearUsuario(usuario);
    }

    // Method to update a user fully by their ID
    @PutMapping("/{id}")
    public Usuario actualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        return usuarioService.actualizarUsuario(id, usuario);
    }

    // Method to update a user partially by their ID
    @PatchMapping("/{id}")
    public Usuario actualizarParcialUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        return usuarioService.actualizarParcialUsuario(id, usuario);
    }

    // Method to delete a user by their ID
    @DeleteMapping("/{id}")
    public void eliminarUsuario(@PathVariable Long id) {
        usuarioService.eliminarUsuario(id);
    }
}
