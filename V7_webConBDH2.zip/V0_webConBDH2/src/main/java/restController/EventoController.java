package restController;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

import com.example.demo.aplication.model.Evento;
import com.example.demo.aplication.model.Usuario;
import com.example.demo.aplication.service.EventoService;
import com.example.demo.aplication.service.UsuarioService;

import java.util.Map;
@RestController
@RequestMapping("/eventos")
public class EventoController {
    @Autowired
    private EventoService eventoService;
    @Autowired
    private UsuarioService usuarioService;
    
    @PostMapping
public ResponseEntity<Evento> crearEvento(@RequestBody Evento evento) {
    Optional<Usuario> usuarioOpt = usuarioService.obtenerUsuarioPorNombreUsuario(evento.getOrganizador().getNombreUsuario());
    if (usuarioOpt.isPresent()) {
        evento.setOrganizador(usuarioOpt.get());
        Evento eventoGuardado = eventoService.crearEvento(evento);
        return ResponseEntity.ok(eventoGuardado);
    } else {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
    }
}


    @GetMapping("/{id}")
public ResponseEntity<Evento> obtenerEvento(@PathVariable Long id) {
    Optional<Evento> eventoOptional = eventoService.obtenerEventoPorId(id);
    if (eventoOptional.isPresent()) {
        return ResponseEntity.ok(eventoOptional.get());
    } else {
        return ResponseEntity.notFound().build();
    }
}


@PutMapping("/{id}")
public ResponseEntity<Evento> updateEvento(@PathVariable Long id, @RequestBody Evento eventoDetails) {
    Optional<Evento> eventoData = eventoService.findById(id);
    if (eventoData.isPresent()) {
        Evento evento = eventoData.get();
        // Suponiendo que tienes métodos setters para actualizar tu evento
        evento.setTitulo(eventoDetails.getTitulo());
        evento.setDescripcion(eventoDetails.getDescripcion());
        // Continúa con otros campos...
        final Evento updatedEvento = eventoService.crearEvento(evento);
        return ResponseEntity.ok(updatedEvento);
    } else {
        return ResponseEntity.notFound().build();
    }
}
@PatchMapping("/{id}")
public ResponseEntity<?> actualizarParcialEvento(@PathVariable Long id, @RequestBody Map<String, Object> updates) {
    Optional<Evento> updatedEvento = eventoService.actualizarParcialmenteEvento(id, updates);
    if (updatedEvento.isPresent()) {
        return ResponseEntity.ok(updatedEvento.get());
    } else {
        return ResponseEntity.notFound().build();
    }
}

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEvento(@PathVariable Long id) {
        eventoService.eliminarEvento(id);
        return ResponseEntity.ok().build();
    }
}
