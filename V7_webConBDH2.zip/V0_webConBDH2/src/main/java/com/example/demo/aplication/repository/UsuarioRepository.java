package com.example.demo.aplication.repository;



import java.util.Optional;

//import java.util.List; //Import para el List().

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.aplication.model.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, String> {

    //atv
    Optional<Usuario> findByNombreUsuario(String nombreUsuario);//podria sobrar


    //fin

    
    
}
