(function ($) {
    "use strict";

    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });




    var formularioEventoEnviado = sessionStorage.getItem('formularioEventoEnviado');
    var titulo = sessionStorage.getItem('tituloEvento');
    var fecha = sessionStorage.getItem('fechaEvento');
    var hora = sessionStorage.getItem('horaEvento');
    var mensaje = sessionStorage.getItem('mensajeEvento');
    var nombreUsuario = sessionStorage.getItem('nombreUsuario');

    // Mapa para almacenar los eventos
    var eventosMap = cargarEventos();

    var contadorId = cargarContadorEventosId();

    function cargarContadorEventosId() {
        var idGuardado = sessionStorage.getItem('ContadorEventosId');
        return idGuardado ? parseInt(idGuardado, 10) : 0; // Cargar el contador, o iniciar en 0 si no existe
    }

    function guardarContadorEventosId() {
        sessionStorage.setItem('ContadorEventosId', contadorId.toString()); // Guardar el contador como cadena
    }

    function generarIdUnico() {
        var id = contadorId++; // Incrementa el contador y lo usa como ID
        guardarContadorEventosId(); // Guardar el nuevo valor del contador en sessionStorage
        return id;
    }

    function cargarEventos() {
        var eventosArray = JSON.parse(sessionStorage.getItem('eventos') || '[]');
        if (eventosArray) {
            return new Map(eventosArray);
        } else {
            return new Map();
        }
    }


    function guardarEventos() {
        var eventosArray = Array.from(eventosMap.entries());
        sessionStorage.setItem('eventos', JSON.stringify(eventosArray));
    }

    function agregarEvento(titulo, fecha, hora, mensaje, nombreUsuario) {
        var id = generarIdUnico(); // Genera un ID único para el nuevo evento
        var nuevoEvento = {
            titulo: titulo,
            fecha: fecha,
            hora: hora,
            mensaje: mensaje,
            nombreUsuario: nombreUsuario
            };
        eventosMap.set(id, nuevoEvento);
        guardarEventos();
        mostrarEventos();
    }

    function mostrarEventos() {
        $('#eventos').empty(); // Limpia el contenedor de eventos antes de mostrar los nuevos
        eventosMap.forEach((evento, id) => {
            // Agrega el nombre del usuario al HTML del evento
            var eventoHTML = `<div class="evento" id="evento-${id}">
                                  <h4>${evento.titulo}</h4>
                                  <p>Creado por: ${evento.nombreUsuario}</p> <!-- Nueva línea para el nombre del usuario -->
                                  <p>Fecha: ${evento.fecha}</p>
                                  <p>Hora: ${evento.hora}</p>
                                  <p>Mensaje: ${evento.mensaje}</p>
                                  <button class="editar-evento btn-primary btn-block font-weight-bold" data-id="${id}">Editar</button>
                                  <button class="eliminar-evento btn-primary btn-block font-weight-bold" data-id="${id}">Eliminar</button>
                              </div>`;
            $('#eventos').append(eventoHTML);
        });
    }

    /*
    function agregarReservaAjax(nombrePersona, fecha, hora, personas) {
        // Construye el objeto de reserva
        var nuevaReserva = {
            nombre: nombrePersona,
            fecha: fecha,
            hora: hora,
            personas: personas
        };

        // Realiza la solicitud AJAX al backend para guardar la nueva reserva
        $.ajax({
            url: 'http://localhost:8080/api/reservas', // Asegúrate de que la URL sea correcta
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(nuevaReserva),
            success: function (reservaGuardada) {
                console.log("Reserva agregada exitosamente", reservaGuardada);
                mostrarReservas(); // Actualiza la lista de reservas (necesitarás implementar esta lógica basada en la respuesta del backend)
            },
            error: function (xhr, status, error) {
                console.error("Error al agregar la reserva", error);
            }
        });
    }

    */

    

    

    function eliminarEvento(id) {
        eventosMap.delete(id);
        guardarEventos();
        mostrarEventos();
    }

    


    if (formularioEventoEnviado === 'true') {
        agregarEvento(titulo, fecha, hora, mensaje,nombreUsuario);
        // Limpiamos el indicador en localStorage
        sessionStorage.removeItem('formularioEventoEnviado');
        sessionStorage.removeItem('titulo');
        sessionStorage.removeItem('fecha');
        sessionStorage.removeItem('hora');
        sessionStorage.removeItem('mensaje');
        sessionStorage.removeItem('nombreUsuario');
        formularioEventoEnviado = 'false'; //no se si sobra,porque se elimina arriba
    } else {
        // Mostrar las reservas existentes al cargar la página
        mostrarEventos();
    }

    
    $(document).ready(function() {
        // Otros códigos de inicialización

        // Delegación de eventos para capturar clic en botones de eliminar
        $('#eventos').on('click', '.eliminar-evento', function() {
            var idEvento = parseInt($(this).data('id'));
            eliminarEvento(idEvento);
        });

        // Delegación de eventos para capturar clic en botones de editar
        $('#eventos').on('click', '.editar-evento', function() {
            var eventoId = $(this).data('id');
            sessionStorage.setItem('editandoEvento', 'true');
            sessionStorage.setItem('eventoId', eventoId.toString());
            window.location.href = 'crearEvento.html'; // Asegúrate de que esta URL sea correcta
        });
    });

   


    
})(jQuery);
