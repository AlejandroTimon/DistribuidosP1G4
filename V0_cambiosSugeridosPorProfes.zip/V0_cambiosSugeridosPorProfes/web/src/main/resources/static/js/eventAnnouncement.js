(function ($) {
    "use strict";

    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Date and time picker
    $('.date').datetimepicker({
        format: 'L'
    });
    $('.time').datetimepicker({
        format: 'LT'
    });










    $(document).ready(function() {
        // Verificar si la página se cargó para editar una reserva
        var editandoEvento = sessionStorage.getItem('editandoEvento');
        var eventoId = sessionStorage.getItem('eventoId');

        
    
        if (editandoEvento === 'true' && eventoId) {
            
            cargarDatosEvento(eventoId) // Cargar los datos de la reserva en el formulario
        } // No se necesita un else si el formulario ya está por defecto vacío para nuevas reservas
    
        


        function getMapaEventos() {
            var eventosArray = JSON.parse(sessionStorage.getItem('eventos') || '[]'); // Añade un valor predeterminado en caso de que no haya eventos
            var eventosMap = new Map();
            eventosArray.forEach((item) => {
                eventosMap.set(item[0], item[1]);
            });
            return eventosMap;
        }

         
        
        function getEvento(mapa, id) {
            return mapa.get(parseInt(id));
        }

        function cargarDatosEvento(id) {
            var eventosMap = getMapaEventos(); // Obtiene el mapa de eventos actual
            var evento = getEvento(eventosMap, id); // Obtiene el evento específico por ID
        
            // Asegura que los campos 'titulo', 'fecha', 'hora', 'mensaje' y 'nombreUsuario' están definidos
            $('#titulo').val(evento.titulo);
            $('#date input').val(evento.fecha); // Asegúrate de que este selector apunta correctamente al input dentro de #date
            $('#time input').val(evento.hora); // Asegúrate de que este selector apunta correctamente al input dentro de #time
            $('#message').val(evento.mensaje);
            $('#nombre').val(evento.nombreUsuario); // Carga el nombre del usuario que creó el evento
        }

        function cargarUsuarios() {
            var usuariosArray = JSON.parse(sessionStorage.getItem('usuarios') || '[]');
            return new Map(usuariosArray);
        }

        

        if (editandoEvento === null){//nuevo evento

            

            // Captura del evento de envío del formulario
            $('form').submit(function (event) {

                


                event.preventDefault(); // Evita que el formulario se envíe


                var nombreUsuario = $('#nombre').val(); // Asume que este es el campo para el nombre de usuario
                var usuariosMap = cargarUsuarios();


                if (!usuariosMap.has(nombreUsuario)) {
                    $('#mensaje').html('El nombre de usuario <strong>' + nombreUsuario + '</strong> no existe. Por favor, crea un usuario primer o escriba uno ya existente.').show();
                    return;
                }

                // Almacenamiento de los datos del evento
                sessionStorage.setItem('formularioEventoEnviado', 'true'); // Indicador de que el evento ha sido enviado
                sessionStorage.setItem('tituloEvento', $('#titulo').val());
                sessionStorage.setItem('fechaEvento', $('#date input').val());
                sessionStorage.setItem('horaEvento', $('#time input').val());
                sessionStorage.setItem('mensajeEvento', $('#message').val());
                sessionStorage.setItem('nombreUsuario', $('#nombre').val());

                

                // Mostramos el mensaje personalizado dentro del elemento #mensaje
                $('#mensaje').html('Evento realizada para <strong>' + nombreUsuario + '</strong>.').show();


                // Opcional: puedes resetear el formulario después de mostrar el mensaje
                this.reset();

                // Esperar 5 segundos antes de redirigir
                setTimeout(function() {
                    window.location.href = 'eventos.html';
                }, 2500); // 2500 milisegundos = 2.5 segundos

                });
        }
        
        
        


        else{//editando reserva
            

            // Limpiar las variables para no afectar futuras cargas de la página
            sessionStorage.removeItem('editandoEvento');
            sessionStorage.removeItem('eventoId');
            
            $('form').submit(function (event) {

                event.preventDefault(); // Evita que el formulario se envíe
                
                var nombreUsuario = $('#nombre').val(); // Asume que este es el campo para el nombre de usuario
                var usuariosMap = cargarUsuarios();

                if (!usuariosMap.has(nombreUsuario)) {
                    $('#mensaje').html('El nombre de usuario <strong>' + nombreUsuario + '</strong> no existe. Por favor, crea un usuario primero o escriba uno ya existente.').show();
                    return;
                }
                
                
                var eventosMap = getMapaEventos();    
                
                //var reserva = getReserva(reservasMap,reservaId);//sobra creo

                // Recoger los valores actuales del formulario
                var titulo = $('#titulo').val();
                var fecha = $('#date input').val();
                var hora = $('#time input').val();
                var mensaje = $('#message').val();

                eventosMap.set(parseInt(eventoId), {
                    usuario: nombreUsuario,
                    titulo: titulo,
                    fecha: fecha,
                    hora: hora,
                    mensaje: mensaje
                });

                var nuevoEventosArray = Array.from(eventosMap.entries());
                sessionStorage.setItem('eventos', JSON.stringify(nuevoEventosArray));

                


                /// Mostramos el mensaje personalizado dentro del elemento #mensaje
                $('#mensaje').html('Evento MODIFICADO para <strong>' + nombreUsuario + '</strong>.').show();


                // Opcional: puedes resetear el formulario después de mostrar el mensaje
                this.reset();

               // Esperar 5 segundos antes de redirigir
                setTimeout(function() {
                    window.location.href = 'eventos.html';
                }, 2500); // 2500 milisegundos = 2.5 segundos








            });    
            
            





        }

    });

    




    


    
    
    

    

    

})(jQuery);
