package com.example.demo.aplication.model;



import java.time.LocalDateTime;

public class Evento {
    private Long id;
    private String titulo;
    private String descripcion;
    private LocalDateTime fechaEvento;
    private String organizador;

    // Constructor vacío
    public Evento() {
    }

    // Constructor con parámetros
    public Evento(Long id, String titulo, String descripcion, LocalDateTime fechaEvento, String organizador) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fechaEvento = fechaEvento;
        this.organizador = organizador;
    }

    // Getters
    public Long getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public LocalDateTime getFechaEvento() {
        return fechaEvento;
    }

    public String getOrganizador() {
        return organizador;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setFechaEvento(LocalDateTime fechaEvento) {
        this.fechaEvento = fechaEvento;
    }

    public void setOrganizador(String organizador) {
        this.organizador = organizador;
    }

    @Override
    public String toString() {
        return "Evento{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", fechaEvento=" + fechaEvento +
                ", organizador='" + organizador + '\'' +
                '}';
    }
}
