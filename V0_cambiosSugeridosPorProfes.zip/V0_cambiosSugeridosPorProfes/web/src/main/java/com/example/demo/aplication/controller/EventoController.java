package com.example.demo.aplication.controller;

import org.springframework.web.bind.annotation.*;

import com.example.demo.aplication.model.Evento;
import com.example.demo.aplication.service.EventoService;

import java.util.List;

// Controller class for managing event-related HTTP requests
@RestController
@RequestMapping("/api/eventos") // Base URL for all methods in this class
public class EventoController {
    private EventoService eventoService = new EventoService(); // Service class to handle business logic

    // Method to list all events
    @GetMapping
    public List<Evento> listarEventos() {
        return eventoService.listarEventos();
    }

    // Method to fetch an event by its ID
    @GetMapping("/{id}")
    public Evento obtenerEventoPorId(@PathVariable Long id) {
        return eventoService.obtenerEventoPorId(id);
    }

    // Method to create a new event
    @PostMapping
    public Evento crearEvento(@RequestBody Evento evento) {
        return eventoService.crearEvento(evento);
    }

    // Method to update an event fully by its ID
    @PutMapping("/{id}")
    public Evento actualizarEvento(@PathVariable Long id, @RequestBody Evento evento) {
        return eventoService.actualizarEvento(id, evento);
    }

    // Method to update an event partially by its ID
    @PatchMapping("/{id}")
    public Evento actualizarParcialEvento(@PathVariable Long id, @RequestBody Evento evento) {
        return eventoService.actualizarParcialEvento(id, evento);
    }

    // Method to delete an event by its ID
    @DeleteMapping("/{id}")
    public void eliminarEvento(@PathVariable Long id) {
        eventoService.eliminarEvento(id);
    }
}
