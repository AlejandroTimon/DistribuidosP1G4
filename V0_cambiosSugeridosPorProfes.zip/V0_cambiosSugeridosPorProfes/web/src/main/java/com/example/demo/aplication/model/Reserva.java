package com.example.demo.aplication.model;

import java.time.LocalDateTime;

// Class representing a reservation entity
public class Reserva {

    private Long id; // Unique identifier for the reservation
    private String nombreUsuario; // Name of the user making the reservation
    private String email; // Email of the user making the reservation
    private LocalDateTime fecha; // Date and time of the reservation
    private int numeroPersonas; // Number of people included in the reservation

    // Default constructor
    public Reserva() {
    }

    // Getters and setters for each field
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public int getNumeroPersonas() {
        return numeroPersonas;
    }

    public void setNumeroPersonas(int numeroPersonas) {
        this.numeroPersonas = numeroPersonas;
    }
}
