package com.example.demo.aplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.aplication.model.Evento;
import com.example.demo.aplication.repository.EventoRepository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class EventoService {
    @Autowired
    private EventoRepository eventoRepository;

    public List<Evento> listarTodosLosEventos() {
        return eventoRepository.findAll();
    }

    public Evento crearEvento(Evento evento) {
        return eventoRepository.save(evento);
    }

    public Optional<Evento> obtenerEventoPorId(Long id) {
        return eventoRepository.findById(id);
    }
    public boolean eliminarEvento(Long id) {
        if (eventoRepository.existsById(id)) {
            eventoRepository.deleteById(id);
            return true;
        }
        return false;
    }
    public Optional<Evento> findById(Long id) {
        return eventoRepository.findById(id);
    }

    

   
    public Optional<Evento> actualizarEvento(Long id, Evento eventoActualizado) {
        return eventoRepository.findById(id)
            .map(evento -> {
                evento.setTitulo(eventoActualizado.getTitulo());
                evento.setDescripcion(eventoActualizado.getDescripcion());
                evento.setFechaEvento(eventoActualizado.getFechaEvento());
                evento.setOrganizador(eventoActualizado.getOrganizador());
                return eventoRepository.save(evento);
            });
    }
    public Optional<Evento> actualizarParcialmenteEvento(Long id, Map<String, Object> updates) {
        return eventoRepository.findById(id)
            .map(evento -> {
                if (((Evento) updates).getTitulo() != null) evento.setTitulo(((Evento) updates).getTitulo());
                if (((Evento) updates).getDescripcion() != null) evento.setDescripcion(((Evento) updates).getDescripcion());
                if (((Evento) updates).getFechaEvento() != null) evento.setFechaEvento(((Evento) updates).getFechaEvento());
                if (((Evento) updates).getOrganizador() != null) evento.setOrganizador(((Evento) updates).getOrganizador());
                return eventoRepository.save(evento);
            });
    }
}
