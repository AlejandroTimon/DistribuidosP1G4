package com.example.demo.aplication.repository;




//import java.util.List; //Import para el List().

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.aplication.model.Evento;

public interface EventoRepository extends JpaRepository<Evento, Long> {
    
}
