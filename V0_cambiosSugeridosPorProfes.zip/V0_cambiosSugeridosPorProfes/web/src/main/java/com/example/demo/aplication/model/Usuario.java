package com.example.demo.aplication.model;

// Class representing a user entity
public class Usuario {
    private Long id; // Unique identifier for the user
    private String nombre; // Name of the user
    private String email; // Email of the user

    // Default constructor
    public Usuario() {
    }

    // Parameterized constructor to create a new user with given details
    public Usuario(Long id, String nombre, String email) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
    }

    // Getter and setter methods for each field
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
