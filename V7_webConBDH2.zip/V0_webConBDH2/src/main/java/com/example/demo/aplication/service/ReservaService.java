package com.example.demo.aplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.aplication.model.Reserva;
import com.example.demo.aplication.repository.ReservaRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ReservaService {
    @Autowired
    private ReservaRepository reservaRepository;

    public List<Reserva> listarTodasLasReservas() {
        return reservaRepository.findAll();
    }

    public Reserva crearReserva(Reserva reserva) {
        return reservaRepository.save(reserva);
    }

    public Optional<Reserva> obtenerReservaPorId(Long id) {
        return reservaRepository.findById(id);
    }

    public Optional<Reserva> actualizarReserva(Long id, Reserva reservaActualizada) {
        return reservaRepository.findById(id)
            .map(reserva -> {
                reserva.setUsuario(reservaActualizada.getUsuario());
                reserva.setComensales(reservaActualizada.getComensales());
                reserva.setFecha(reservaActualizada.getFecha());
                reserva.setHora(reservaActualizada.getHora());
                return reservaRepository.save(reserva);
            });
    }

    public Optional<Reserva> actualizarParcialmenteReserva(Long id, Reserva cambios) {
        return reservaRepository.findById(id)
            .map(reserva -> {
                if (cambios.getUsuario() != null) reserva.setUsuario(cambios.getUsuario());
                if (cambios.getComensales() != null) reserva.setComensales(cambios.getComensales());
                if (cambios.getFecha() != null) reserva.setFecha(cambios.getFecha());
                if (cambios.getHora() != null) reserva.setHora(cambios.getHora());
                return reservaRepository.save(reserva);
            });
    }

    public boolean eliminarReserva(Long id) {
        if (reservaRepository.existsById(id)) {
            reservaRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
