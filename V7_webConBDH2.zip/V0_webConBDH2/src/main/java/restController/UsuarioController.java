package restController;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.aplication.model.Usuario;
import com.example.demo.aplication.service.UsuarioService;


import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    @Autowired
    private UsuarioService usuarioService;

    @GetMapping
    public List<Usuario> obtenerTodosLosUsuarios() {
        return usuarioService.listarUsuarios();
    }

    @PostMapping
    public Usuario crearUsuario(@RequestBody Usuario usuario) {
        return usuarioService.guardarUsuario(usuario);
    }

    @GetMapping("/{nombreUsuario}")
    public ResponseEntity<Usuario> obtenerUsuarioPorNombreUsuario(@PathVariable String nombreUsuario) {
        return usuarioService.obtenerUsuarioPorNombreUsuario(nombreUsuario)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{nombreUsuario}")
    public ResponseEntity<Usuario> actualizarUsuario(@PathVariable String nombreUsuario, @RequestBody Usuario usuario) {
        return usuarioService.actualizarUsuario(nombreUsuario, usuario)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{nombreUsuario}")
    public ResponseEntity<Usuario> actualizarParcialmenteUsuario(@PathVariable String nombreUsuario, @RequestBody Map<String, Object> updates) {
        return usuarioService.actualizarUsuarioParcialmente(nombreUsuario, updates)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{nombreUsuario}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable String nombreUsuario) {
        if (usuarioService.eliminarUsuario(nombreUsuario)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}
