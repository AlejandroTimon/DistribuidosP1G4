package com.example.demo.aplication.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.aplication.model.Evento;
import com.example.demo.aplication.model.Usuario;
import com.example.demo.aplication.service.EventoService;
import com.example.demo.aplication.service.UsuarioService;

@Controller
@RequestMapping("/eventos")
public class EventoController {
    @Autowired
    private EventoService eventoService;

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/misEventos")
    public String obtenerTodosLosEventos(Model model) {
        List<Evento> eventList = eventoService.listarTodosLosEventos();
        model.addAttribute("eventList", eventList);
        return "eventos";  // Assumes there is a 'misEventos' template to display events
    }

    

    @GetMapping("/createEvento")
    public String formularioCrearEvento(Model model) {
        model.addAttribute("evento", new Evento());
        model.addAttribute("action", "/eventos/createEvento");
        model.addAttribute("error", "");
        
        return "/crearEvento";  // Assumes there is a 'registroEvento' template for the event registration form
    }

    @PostMapping("/createEvento")
    public String crearEvento(@ModelAttribute Evento evento, Model model, @RequestParam("nombreUsuario") String nombreUsuario) {
        Optional<Usuario> maybeUsuario = usuarioService.obtenerUsuarioPorId(nombreUsuario);

        if (!usuarioService.nombreUsuarioExiste(nombreUsuario)) {
            model.addAttribute("error", "El usuario introducido no existe, por favor cree uno o introduzca uno ya existente.");
            model.addAttribute("action", "/eventos/createEvento");
            return "crearEvento"; // Registration form template name.
        }

        evento.setOrganizador(maybeUsuario.get());
        eventoService.crearEvento(evento);
        return "redirect:/eventos/misEventos";
    }


    

    @GetMapping("/edit/{id}")
    public String formularioEditarEvento(@PathVariable Long id, Model model) {
        Optional<Evento> maybeEvento = eventoService.obtenerEventoPorId(id);
        if (!maybeEvento.isPresent()) {
            return "redirect:/error.html";  // Redirects to a controlled route that shows an error page
        }
        Evento evento = maybeEvento.get();
        model.addAttribute("evento", evento);
        model.addAttribute("action", "/eventos/edit/" + id);
        
        return "/actualizarEvento";  // Name of the event update form template
    }

    @PostMapping("/edit/{id}")
    public String editarEvento(@PathVariable Long id, @ModelAttribute Evento evento, Model model, @RequestParam("evento.organizador.nombreUsuario") String nombreUsuario) {
        Usuario organizador = usuarioService.obtenerUsuarioPorId(nombreUsuario).get();
        evento.setOrganizador(organizador);
        eventoService.actualizarEvento(id, evento);
        return "redirect:/eventos/misEventos";
    }

    


    @GetMapping("/remove/{id}")
    public String eliminarEvento(@PathVariable Long id, Model model) {
        Optional<Evento> maybeEvento = eventoService.obtenerEventoPorId(id);
        if (!maybeEvento.isPresent()) {
            return "redirect:/error.html";  // Redirects to a controlled route that shows an error page
        }
        eventoService.eliminarEvento(id);
        return "redirect:/eventos/misEventos";
    }


    
}