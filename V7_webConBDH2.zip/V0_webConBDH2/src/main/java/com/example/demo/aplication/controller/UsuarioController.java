package com.example.demo.aplication.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.aplication.model.Usuario;
import com.example.demo.aplication.service.UsuarioService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
@RequestMapping("/usuarios")
public class UsuarioController {
    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/socios")
    public String obtenerTodosLosUsuarios(Model model) {
        List<Usuario>  userList = usuarioService.listarUsuarios();
        model.addAttribute("userList", userList);
        return "socios";
    }

    @GetMapping("/createUser")
    public String formulariocrearUsuario(Model model) {
        model.addAttribute("usuario",new Usuario());
        model.addAttribute("action", "/usuarios/createUser");
        model.addAttribute("error", "");
        return "/registrarse";
    }

    @PostMapping("/createUser")
    public String crearUsuario(@ModelAttribute Usuario usuario,Model model) {
        
        if (usuarioService.nombreUsuarioExiste(usuario.getNombreUsuario())) {
            model.addAttribute("error", "El nombre de usuario ya está en uso.");
            model.addAttribute("usuario", usuario);
            model.addAttribute("action", "/usuarios/createUser");
            return "registrarse"; // Nombre de la plantilla del formulario de registro.
        }
        
        usuarioService.guardarUsuario(usuario);
        return "redirect:/usuarios/socios";
    }


    //para postman sirve el de abajo
    /* 
    @PostMapping("/createUser")
    public String crearUsuario(@RequestBody  Usuario usuario) {
        usuarioService.crearUsuario(usuario);
        return "redirect:/socios";
    }
    */

    @GetMapping("/edit/{id}")
    public String formularioEditarUsuario(@PathVariable String id,@ModelAttribute Usuario usuario,Model model) {
        Optional<Usuario> maybeUsuario = usuarioService.obtenerUsuarioPorId(id);
        if (!maybeUsuario.isPresent()) {
            return "redirect:/error.html";  // Redirige a una ruta controlada que muestra una página de error
        }
        usuario = maybeUsuario.get();
        model.addAttribute("usuario",usuario);
        model.addAttribute("action", "/usuarios/edit/"+id);
        model.addAttribute("error", "");
        return "/actualizarUser";
    }

    @PostMapping("/edit/{id}")
    public String editarUsuario(@PathVariable String id,@ModelAttribute Usuario usuario,Model model) {
        
        
        
        usuarioService.actualizarParcialmenteUsuario(id,usuario);//pendiente de cambio
        return "redirect:/usuarios/socios";
    }

    //eliminarUsuario

    @GetMapping("/remove/{id}")
    public String eliminarUsuario(@PathVariable String id,@ModelAttribute Usuario usuario,Model model) {
        Optional<Usuario> maybeUsuario = usuarioService.obtenerUsuarioPorId(id);
        if (!maybeUsuario.isPresent()) {
            return "redirect:/error.html";  // Redirige a una ruta controlada que muestra una página de error
        }
        usuarioService.eliminarUsuario(id);
        return "redirect:/usuarios/socios";
    }


    








   
}





/* 
package com.example.demo.aplication.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.aplication.model.Usuario;
import com.example.demo.aplication.service.UsuarioService;

import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    @Autowired
    private UsuarioService usuarioService;

    @GetMapping
    public List<Usuario> obtenerTodosLosUsuarios() {
        return usuarioService.listarTodosLosUsuarios();
    }

    @PostMapping
    public Usuario crearUsuario(@RequestBody Usuario usuario) {
        return usuarioService.crearUsuario(usuario);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Usuario> obtenerUsuarioPorId(@PathVariable Long id) {
        return usuarioService.obtenerUsuarioPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Usuario> actualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        return usuarioService.actualizarUsuario(id, usuario)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Usuario> actualizarParcialmenteUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        return usuarioService.actualizarParcialmenteUsuario(id, usuario)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable Long id) {
        if (usuarioService.eliminarUsuario(id)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}

*/
