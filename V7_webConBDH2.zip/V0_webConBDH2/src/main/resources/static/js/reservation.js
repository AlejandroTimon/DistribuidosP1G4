(function ($) {
    "use strict";

    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Date and time picker
    $('.date').datetimepicker({
        format: 'LT'
    });
    $('.time').datetimepicker({
        format: 'LT'
    });


    $(document).ready(function() {
        $('form').submit(function(event) {
            


            var fechaInput = $('input[name="fecha"]').val();

            var fecha = new Date(fechaInput);
            fecha.setHours(0, 0, 0, 0); // Establece la hora a medianoche
            var ahora = new Date();
            ahora.setHours(0, 0, 0, 0);

            if (fecha <= ahora) {
                $('#mensaje').html('Las reservas no pueden realizarse el mismo día o para fechas pasadas. Mínimo un día de antelación requerido.').show();
                event.preventDefault();
                return;
            }

            

            var horaInput = $('input[name="hora"]').val(); 

            // Separamos las horas y los minutos
            var partesHora = horaInput.split(':');
            var horas = parseInt(partesHora[0], 10); // Convertimos la parte de las horas a número entero
    
            // Verificamos si la hora está fuera del rango permitido
            if (horas < 11 ) {
                $('#mensaje').html('Las reservas deben realizarse entre las 11:00 AM y las 12:00 PM.').show();
                event.preventDefault(); // Detenemos el envío del formulario
            }

            
    
            
        });
    });

})(jQuery);







    /*

    $(document).ready(function() {
        // Verificar si la página se cargó para editar una reserva
        var editando = sessionStorage.getItem('editando');
        var reservaId = sessionStorage.getItem('reservaId');
    
        if (editando === 'true' && reservaId) {
            
            cargarDatosReserva(reservaId); // Cargar los datos de la reserva en el formulario
        } // No se necesita un else si el formulario ya está por defecto vacío para nuevas reservas
    
        

        function getMapaReservas() {
            var reservasArray = JSON.parse(sessionStorage.getItem('reservas'));
            var reservasMap = new Map();
            reservasArray.forEach((item) => {
                reservasMap.set(item[0], item[1]);
            });
            return reservasMap;

        } 
        
        function getReserva(mapa,id) {

            return mapa.get(parseInt(id));
        
        }

        function cargarDatosReserva(id) {

            var reservasMap = getMapaReservas();    
            var reserva = getReserva(reservasMap,id);
            
            //$('#mensaje').html(reserva.persona).show();
            
            $('#nombre').val(reserva.nombre);
            //$('#email').val(reserva.email);
            $('#date input').val(reserva.fecha); // Asegúrate de que este selector apunta correctamente al input dentro de #date
            $('#time input').val(reserva.hora); // Asegúrate de que este selector apunta correctamente al input dentro de #time
            $('#personas').val(reserva.personas.toString());
    

        }

        function cargarUsuarios() {
            var usuariosArray = JSON.parse(sessionStorage.getItem('usuarios') || '[]');
            return new Map(usuariosArray);
        }

        if (editando === null){//nueva reserva

            // Captura del evento de envío del formulario
            $('form').submit(function (event) {


                event.preventDefault(); // Evita que el formulario se envíe




                // Obtener los valores de los inputs de fecha y hora
                var fechaReservaInput = $('#date input').val();
                var horaReservaInput = $('#time input').val();

                // Verificar que la fecha de reserva haya sido ingresada
                if (!fechaReservaInput) {
                    $('#mensaje').html('Es necesario ingresar una fecha para la reserva.').show();
                    return;
                }

                // Verificar que la hora de reserva haya sido ingresada
                if (!horaReservaInput) {
                    $('#mensaje').html('Es necesario ingresar una hora para la reserva.').show();
                    return;
                }

                var fechaReserva = new Date($('#date input').val());
                var ahora = new Date();

                if (fechaReserva <= ahora) {
                    $('#mensaje').html('Las reservas no pueden realizarse el mismo día o para fechas pasadas. Mínimo un día de antelación requerido.').show();
                    return;
                }

                var horaInput = $('#time input').val(); 
                

                var partesHoraReserva = horaInput.split(':');
                var horas = parseInt(partesHoraReserva[0], 10); // Las horas en formato de 12 horas
                var minutosYPeriodo = horaInput.split(' '); // Esto separará los minutos y AM/PM
                var periodo = minutosYPeriodo[1]; // AM o PM

                // Verificar las condiciones basadas en el formato de 12 horas
                if ((periodo === 'AM' && horas < 11 )||(periodo === 'PM' && horas >= 11)){
                    $('#mensaje').html('Las reservas deben realizarse entre las 11:00 AM y las 11:00 PM.').show();
                    return;
                }



                
                
        
                

                


                var nombreUsuario = $('#nombre').val(); // Asume que este es el campo para el nombre de usuario
                var usuariosMap = cargarUsuarios();


                if (!usuariosMap.has(nombreUsuario)) {
                    $('#mensaje').html('El nombre de usuario <strong>' + nombreUsuario + '</strong> no existe. Por favor, crea un usuario primer o escriba uno ya existente.').show();
                    return;
                }

                // Colocamos un indicador en localStorage para indicar que el formulario ha sido enviado
                sessionStorage.setItem('formularioEnviado', 'true');
                sessionStorage.setItem('nombre', $('#nombre').val());
                //sessionStorage.setItem('email', $('#email').val());
                sessionStorage.setItem('fecha', $('#date input').val());
                sessionStorage.setItem('hora', $('#time input').val());
                sessionStorage.setItem('personas', $('#personas option:selected').val());

                // Obtenemos el nombre de la persona seleccionada
                var numeroPersonas = $('#personas option:selected').text();

                // Mostramos el mensaje personalizado dentro del elemento #mensaje
                $('#mensaje').html('Reserva realizada para <strong>' + numeroPersonas + '</strong>.').show();


                // Opcional: puedes resetear el formulario después de mostrar el mensaje
                this.reset();

                // Esperar 5 segundos antes de redirigir
                setTimeout(function() {
                    window.location.href = 'misReservas.html';
                }, 2500); // 2500 milisegundos = 2.5 segundos

                });
        }
        
        
        


        else{//editando reserva

            // Limpiar las variables para no afectar futuras cargas de la página
            sessionStorage.removeItem('editando');
            sessionStorage.removeItem('reservaId');
            
            $('form').submit(function (event) {

                event.preventDefault(); // Evita que el formulario se envíe


                // Obtener los valores de los inputs de fecha y hora
                var fechaReservaInput = $('#date input').val();
                var horaReservaInput = $('#time input').val();

                // Verificar que la fecha de reserva haya sido ingresada
                if (!fechaReservaInput) {
                    $('#mensaje').html('Es necesario ingresar una fecha para la reserva.').show();
                    return;
                }

                // Verificar que la hora de reserva haya sido ingresada
                if (!horaReservaInput) {
                    $('#mensaje').html('Es necesario ingresar una hora para la reserva.').show();
                    return;
                }
                
                var fechaReserva = new Date($('#date input').val());
                var ahora = new Date();

                if (fechaReserva <= ahora) {
                    $('#mensaje').html('Las reservas no pueden realizarse el mismo día o para fechas pasadas. Mínimo un día de antelación requerido.').show();
                    return;
                }

                var horaInput = $('#time input').val(); 
                

                var partesHoraReserva = horaInput.split(':');
                var horas = parseInt(partesHoraReserva[0], 10); // Las horas en formato de 12 horas
                var minutosYPeriodo = horaInput.split(' '); // Esto separará los minutos y AM/PM
                var periodo = minutosYPeriodo[1]; // AM o PM

                // Verificar las condiciones basadas en el formato de 12 horas
                if ((periodo === 'AM' && horas < 11 )||(periodo === 'PM' && horas >= 11)){
                    $('#mensaje').html('Las reservas deben realizarse entre las 11:00 AM y las 11:00 PM.').show();
                    return;
                }



                var nombreUsuario = $('#nombre').val(); // Asume que este es el campo para el nombre de usuario
                var usuariosMap = cargarUsuarios();

                if (!usuariosMap.has(nombreUsuario)) {
                    $('#mensaje').html('El nombre de usuario <strong>' + nombreUsuario + '</strong> no existe. Por favor, crea un usuario primero o escriba uno ya existente.').show();
                    return;
                }
                
                
                var reservasMap = getMapaReservas();    
                
                //var reserva = getReserva(reservasMap,reservaId);//sobra creo

                // Recoger los valores actuales del formulario
                var nombre = $('#nombre').val();
                //var email = $('#email').val();
                var fecha = $('#date input').val();
                var hora = $('#time input').val();
                var personas = $('#personas').val();

                reservasMap.set(parseInt(reservaId), {
                    nombre: nombre,
                    //email: email,
                    fecha: fecha,
                    hora: hora,
                    personas: personas
                });

                var nuevoReservasArray = Array.from(reservasMap.entries());
                sessionStorage.setItem('reservas', JSON.stringify(nuevoReservasArray));

                


                // Obtenemos el nombre de la persona seleccionada
                var numeroPersonas = $('#personas option:selected').text();

                // Mostramos el mensaje personalizado dentro del elemento #mensaje
                $('#mensaje').html('Reserva MODIFICADApara <strong>' + numeroPersonas + '</strong>.').show();


                // Opcional: puedes resetear el formulario después de mostrar el mensaje
                this.reset();

               // Esperar 5 segundos antes de redirigir
                setTimeout(function() {
                    window.location.href = 'misReservas.html';
                }, 2500); // 2500 milisegundos = 2.5 segundos








            });    
            
            





        }

    });

    */


    




    


    
    
    

    

    



