package com.example.demo.aplication.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.aplication.model.Reserva;
import com.example.demo.aplication.model.Usuario;
import com.example.demo.aplication.service.ReservaService;
import com.example.demo.aplication.service.UsuarioService;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/reservas")
public class ReservaController {
    @Autowired
    private ReservaService reservaService;

    @Autowired
    private UsuarioService usuarioService;

    

    @GetMapping("/misReservas")
    public String obtenerTodasLasReservas(Model model) {
        List<Reserva> reservaList = reservaService.listarTodasLasReservas();
        model.addAttribute("reservaList", reservaList);
        return "misReservas";  // Asumimos que hay una plantilla 'reservas' para mostrar las reservas
    }

    
    @GetMapping("/createReserva")
    public String formularioCrearReserva(Model model) {
        model.addAttribute("reserva", new Reserva());
        model.addAttribute("action", "/reservas/createReserva");
        model.addAttribute("error", "");
        
        return "/reserva";  // Asumimos que hay una plantilla 'registrarReserva' para el formulario de registro
    }

    @PostMapping("/createReserva")
    public String crearReserva(@ModelAttribute Reserva reserva, Model model, @RequestParam("nombreUsuario") String nombreUsuario) {
        

        Optional<Usuario> maybeUsuario = usuarioService.obtenerUsuarioPorId(nombreUsuario);

        if (!usuarioService.nombreUsuarioExiste(nombreUsuario)) {
            model.addAttribute("error", "El usuario introducido no existe,cree uno o introduzca uno ya existente");
            model.addAttribute("action", "/reservas/createReserva");
            return "reserva"; // Nombre de la plantilla del formulario de registro.
        }

        
        reserva.setUsuario(maybeUsuario.get());
        reservaService.crearReserva(reserva);
        return "redirect:/reservas/misReservas";
    }




    @GetMapping("/edit/{id}")
    public String formularioEditarReserva(@PathVariable Long id, Model model) {
        Optional<Reserva> maybeReserva = reservaService.obtenerReservaPorId(id);
        if (!maybeReserva.isPresent()) {
            return "redirect:/error.html";  // Redirige a una ruta controlada que muestra una página de error
        }
        Reserva reserva = maybeReserva.get();
        model.addAttribute("reserva", reserva);
        model.addAttribute("action", "/reservas/edit/" + id);
        
        
        return "/actualizarReservation";  // Nombre de la plantilla del formulario de edición de reserva
    }

    @PostMapping("/edit/{id}")
    public String editarReserva(@PathVariable Long id, @ModelAttribute Reserva reserva, Model model,@RequestParam("reserva.usuario.nombreUsuario") String nombreUsuario) {
        

        Usuario usuario = usuarioService.obtenerUsuarioPorId(nombreUsuario).get();

        reserva.setUsuario(usuario);


        reservaService.actualizarReserva(id,reserva);
        return "redirect:/reservas/misReservas";
    }

    //eliminarReserva
    @GetMapping("/remove/{id}")
    public String eliminarReserva(@PathVariable Long id, Model model) {
        Optional<Reserva> maybeReserva = reservaService.obtenerReservaPorId(id);
        if (!maybeReserva.isPresent()) {
            return "redirect:/error.html";  // Redirige a una ruta controlada que muestra una página de error
        }
        reservaService.eliminarReserva(id);
        return "redirect:/reservas/misReservas";
    }



    
}

