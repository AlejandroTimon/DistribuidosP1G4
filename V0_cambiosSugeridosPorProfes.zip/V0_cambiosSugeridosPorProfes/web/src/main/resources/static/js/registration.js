(function ($) {
    "use strict";

    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Date and time picker
    $('.date').datetimepicker({
        format: 'L'
    });
    $('.time').datetimepicker({
        format: 'LT'
    });










    $(document).ready(function() {
        
        
        // Verificar si la página se cargó para editar un usuario
        var editandoUsuario = sessionStorage.getItem('editandoUsuario');
        var usuarioId = sessionStorage.getItem('usuarioId');
    
        if (editandoUsuario === 'true' && usuarioId) {
            cargarDatosUsuario(usuarioId); // Cargar los datos del usuario en el formulario
        }
    
        function cargarUsuarios() {
            var usuariosArray = JSON.parse(sessionStorage.getItem('usuarios') || '[]');
            var usuariosMap = new Map();
            usuariosArray.forEach((item) => {
                usuariosMap.set(item[0], item[1]);
            });
            return usuariosMap;
        }
        
        function getUsuario(mapa, id) {
            return mapa.get(id);
        }

        function cargarDatosUsuario(id) {
            var usuariosMap = cargarUsuarios();    
            var usuario = getUsuario(usuariosMap, id);
            
            $('#nombre').val(usuario.nombreCompleto);
            $('#usuario').val(usuario.nombreUsuario).attr('readonly', true); // Hacer el campo de solo lectura
            $('#email').val(usuario.correoElectronico);
            $('#date input').val(usuario.fechaNacimiento);
        }

        if (editandoUsuario === null){//nueva reserva

            // Captura del evento de envío del formulario
            $('form').submit(function (event) {
                event.preventDefault(); // Evita que el formulario se envíe
    
                
                var nombreUsuario = $('#usuario').val();

                

                // Verifica si el nombre de usuario ya existe
                if (nombreUsuarioExiste(nombreUsuario)) {
                    $('#mensaje').html('El nombre de usuario <strong>' + nombreUsuario + '</strong> ya está creado. Por favor, elige otro.').show();
                    return; // Detiene la ejecución si el nombre de usuario ya existe
                }

                

                function nombreUsuarioExiste(nombreUsuario) {
                    var usuariosMap = cargarUsuarios();
                    return usuariosMap.has(nombreUsuario);
                }

                // Coloca indicadores en sessionStorage para indicar que el registro ha sido completado
                sessionStorage.setItem('formularioUsuarioEnviado', 'true');
                sessionStorage.setItem('nombreCompleto', $('#nombre').val());
                sessionStorage.setItem('nombreUsuario', $('#usuario').val());
                sessionStorage.setItem('correoElectronico', $('#email').val());
                sessionStorage.setItem('fechaNacimiento', $('#date input').val());
    
                // Mostramos el mensaje personalizado dentro del elemento #mensaje
                $('#mensaje').html('Registro realizado para <strong>' + $('#nombre').val() + '</strong>.').show();
    
                // Opcional: puedes resetear el formulario después de mostrar el mensaje
                this.reset();

            // Esperar 5 segundos antes de redirigir
            setTimeout(function() {
                window.location.href = 'socios.html';
            }, 2500); // 2500 milisegundos = 2.5 segundos

            });
        }
        
        
        


        else{//editando usuario

            // Limpiar las variables para no afectar futuras cargas de la página
            sessionStorage.removeItem('editandoUsuario');
            sessionStorage.removeItem('usuarioId');
            
            $('form').submit(function (event) {

                event.preventDefault(); // Evita que el formulario se envíe
                var usuariosMap = cargarUsuarios();   
                
                

                // Recoger los valores actuales del formulario
                var nombreCompleto = $('#nombre').val();
                var nombreUsuario = $('#usuario').val();
                var correoElectronico = $('#email').val();
                var fechaNacimiento = $('#date input').val();

                usuariosMap.set(usuarioId, {
                    nombreCompleto: nombreCompleto,
                    nombreUsuario: nombreUsuario,
                    correoElectronico: correoElectronico,
                    fechaNacimiento: fechaNacimiento
                });

                var nuevosUsuariosArray = Array.from(usuariosMap.entries());
                sessionStorage.setItem('usuarios', JSON.stringify(nuevosUsuariosArray));


                // Mostramos el mensaje personalizado dentro del elemento #mensaje
                $('#mensaje').html('Usuario <strong>modificado</strong> para <strong>' + nombreUsuario + '</strong>.').show();

                // Opcional: puedes resetear el formulario después de mostrar el mensaje
                this.reset();

               // Esperar 5 segundos antes de redirigir
               setTimeout(function() {
                    window.location.href = 'socios.html';
                }, 2500); // 2500 milisegundos = 2.5 segundos
                    







            });    
            
            





        }

    });

    




    


    
    
    

    

    

})(jQuery);
