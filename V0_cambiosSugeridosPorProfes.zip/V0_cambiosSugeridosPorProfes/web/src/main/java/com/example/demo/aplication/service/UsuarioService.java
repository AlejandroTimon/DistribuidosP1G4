package com.example.demo.aplication.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import com.example.demo.aplication.model.Usuario;

// Service class for user-related business operations
public class UsuarioService {
    private final List<Usuario> usuarios = new ArrayList<>(); // Mocked list of users
    private final AtomicLong contador = new AtomicLong(); // Counter for generating unique IDs

    // Returns the list of all users
    public List<Usuario> listarUsuarios() {
        return usuarios;
    }

    // Finds and returns a user by ID, or null if not found
    public Usuario obtenerUsuarioPorId(Long id) {
        return usuarios.stream().filter(usuario -> usuario.getId().equals(id)).findFirst().orElse(null);
    }

    // Adds a new user to the list with a unique ID
    public Usuario crearUsuario(Usuario usuario) {
        usuario.setId(contador.incrementAndGet());
        usuarios.add(usuario);
        return usuario;
    }

    // Updates a user by ID with the provided user details
    public Usuario actualizarUsuario(Long id, Usuario usuarioActualizado) {
        Usuario usuario = obtenerUsuarioPorId(id);
        if (usuario != null) {
            usuario.setNombre(usuarioActualizado.getNombre());
            usuario.setEmail(usuarioActualizado.getEmail());
            return usuario;
        }
        return null;
    }

    // Deletes a user by ID
    public void eliminarUsuario(Long id) {
        usuarios.removeIf(usuario -> usuario.getId().equals(id));
    }

    // Partially updates a user's details by ID
    public Usuario actualizarParcialUsuario(Long id, Usuario usuarioParcial) {
        Usuario usuario = obtenerUsuarioPorId(id);
        if (usuario != null) {
            if (usuarioParcial.getNombre() != null) usuario.setNombre(usuarioParcial.getNombre());
            if (usuarioParcial.getEmail() != null) usuario.setEmail(usuarioParcial.getEmail());
            return usuario;
        }
        return null;
    }
}
