package com.example.demo.aplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.aplication.model.Evento;
import com.example.demo.aplication.model.Reserva;
import com.example.demo.aplication.model.Usuario;
import com.example.demo.aplication.repository.EventoRepository;
import com.example.demo.aplication.repository.ReservaRepository;
import com.example.demo.aplication.repository.UsuarioRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private EventoRepository eventoRepository;

    @Autowired
    private ReservaRepository reservaRepository;

    //atv

    public boolean nombreUsuarioExiste(String nombreUsuario) {
        // Verificar en la base de datos si el nombre de usuario ya existe.
        // Esto dependerá de cómo tengas implementado tu repositorio.
        return usuarioRepository.findByNombreUsuario(nombreUsuario).isPresent();
    }

    public Optional<Usuario> obtenerUsuarioPorId(String id) {
        return usuarioRepository.findById(id);
    }

    //fin

    public Usuario guardarUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public Optional<Usuario> obtenerUsuarioPorNombreUsuario(String nombreUsuario) {
        return usuarioRepository.findById(nombreUsuario);
    }

    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    public boolean eliminarUsuario(String nombreUsuario) {
        if (usuarioRepository.existsById(nombreUsuario)) {
            usuarioRepository.deleteById(nombreUsuario);
            return true;
        }
        return false;
    }

    public Evento agregarEventoAUsuario(String nombreUsuario, Evento evento) {
        Usuario usuario = usuarioRepository.findById(nombreUsuario).orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        evento.setOrganizador(usuario);
        return eventoRepository.save(evento);
    }

    public Reserva agregarReservaAUsuario(String nombreUsuario, Reserva reserva) {
        Usuario usuario = usuarioRepository.findById(nombreUsuario).orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        reserva.setUsuario(usuario);
        return reservaRepository.save(reserva);
    }

    public Optional<Usuario> actualizarUsuario(String nombreUsuario, Usuario detalles) {
        Optional<Usuario> usuarioExistente = usuarioRepository.findById(nombreUsuario);
        if (usuarioExistente.isPresent()) {
            Usuario actualizado = usuarioExistente.get();
            actualizado.setNombre(detalles.getNombre());
            actualizado.setEmail(detalles.getEmail());
            actualizado.setFecha(detalles.getFecha());
            actualizado.setNombreUsuario(detalles.getNombreUsuario());
            return Optional.of(usuarioRepository.save(actualizado));
        }
        return Optional.empty();
    }

    public Optional<Usuario> actualizarUsuarioParcialmente(String nombreUsuario, Map<String, Object> updates) {
        return usuarioRepository.findById(nombreUsuario).map(usuarioExistente -> {
            updates.forEach((key, value) -> {
                switch (key) {
                    case "nombre":
                        usuarioExistente.setNombre((String) value);
                        break;
                    case "email":
                        usuarioExistente.setEmail((String) value);
                        break;
                    case "fechaNacimiento":
                        if (value instanceof String) {
                            usuarioExistente.setFecha(LocalDate.parse((String) value));
                        } else {
                            usuarioExistente.setFecha((LocalDate) value);
                        }
                        break;
                    case "nombreUsuario":
                        usuarioExistente.setNombreUsuario((String) value);
                        break;
                }
            });
            return usuarioRepository.save(usuarioExistente);
        });
    }

    //el de atv
    public Optional<Usuario> actualizarParcialmenteUsuario(String id, Usuario usuarioActualizado) {
        return usuarioRepository.findById(id)
            .map(usuario -> {
                if (usuarioActualizado.getNombre() != null) usuario.setNombre(usuarioActualizado.getNombre());
                if (usuarioActualizado.getEmail() != null) usuario.setEmail(usuarioActualizado.getEmail());
                if (usuarioActualizado.getNombreUsuario() != null) usuario.setNombreUsuario(usuarioActualizado.getNombreUsuario());
                if (usuarioActualizado.getFecha() != null) usuario.setFecha(usuarioActualizado.getFecha());
                // Añadir aquí otros campos que puedan ser actualizados parcialmente
                return usuarioRepository.save(usuario);
            });
    }
    



}
